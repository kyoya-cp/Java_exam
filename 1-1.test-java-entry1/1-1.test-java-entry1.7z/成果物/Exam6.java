public class Exam6
{
	public static void main( String[] args )
	{
		String statement ;

		statement = "Steve Jobs said \n\"Stay Hungry. Stay Foolish\"" ;

		System.out.println( statement ) ;
	}
}
