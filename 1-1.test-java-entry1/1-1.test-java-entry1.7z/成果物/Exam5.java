public class Exam5
{
	public static void main( String[] args )
	{
		System.out.println( "1.byte" ) ;
		System.out.println( "2.short" ) ;
		System.out.println( "3.long" ) ;
		System.out.println( "4.boolean" ) ;
		System.out.println( "5.int" ) ;
		System.out.println( "6.char" ) ;
		System.out.println( "7.float" ) ;
		System.out.println( "8.double" ) ;
	}
}
